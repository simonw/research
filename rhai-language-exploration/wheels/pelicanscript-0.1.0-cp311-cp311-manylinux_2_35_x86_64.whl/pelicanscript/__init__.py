from .pelicanscript import *

__doc__ = pelicanscript.__doc__
if hasattr(pelicanscript, "__all__"):
    __all__ = pelicanscript.__all__